// datatbase.js
const mysql = require('mysql2');    // mysql2(MySQL 연결)
require('dotenv').config();// .env 파일에서 환경변수 불러오기

const {
    DB_HOST,
    DB_USER,
    DB_PASS,
    DB_DB,
  } = process.env;

const pool = mysql.createPool({
  host: DB_HOST,
  user: DB_USER,
  password: DB_PASS,
  database: DB_DB,
  waitForConnections: true,
  connectionLimit: 10,
});

module.exports = pool;