package com.example.notishare;

import androidx.annotation.NonNull;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class DTO {
    @Expose

    @SerializedName("ID")
    private String id;
    @SerializedName("PACKAGENAME")
    private String packagen;
    @SerializedName("TITLE")
    private String title;
    @SerializedName("TEXT")
    private String text;
    @SerializedName("BIGTEXT")
    private String bigtext;
    @SerializedName("INFOTEXT")
    private String infotext;
    @SerializedName("SUBTEXT")
    private String subtext;
    @SerializedName("SUMMARYTEXT")
    private String st;
    @SerializedName("TIME")
    private String time;

    @SerializedName("result")
    private String result;

    public void setResult(String result){
        this.result = result;
    }

    public String getResult(){
        return result;
    }

    private String APIKEY = "6fOZo67k16eYekCMGIvzYlpT07YEC5zwmAl79XhYjil8doJariSkZ4RrUlwhrKGGLnQW2P3ek6Fl+pxkxnfr6g==";

    public String getAPIKEY(){
        return APIKEY;
    }

    public String getPackagen() {
        return packagen;
    }

    public void setPackagen(String packagen) {
        this.packagen = packagen;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public String getBigtext() {
        return bigtext;
    }

    public void setBigtext(String bigtext) {
        this.bigtext = bigtext;
        if(this.bigtext == null){
            this.bigtext = "";
        }
    }

    public String getInfotext() {
        return infotext;
    }

    public void setInfotext(String infotext) {
        this.infotext = infotext;
        if(this.infotext == null){
            this.infotext = "";
        }
    }

    public String getSubtext() {
        return subtext;
    }

    public void setSubtext(String subtext) {
        this.subtext = subtext;
        if(this.subtext == null){
            this.subtext = "";
        }
    }

    public String getSt() {
        return st;
    }

    public void setSt(String st) {
        this.st = st;
        if(this.st == null){
            this.st = "";
        }
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }


}
