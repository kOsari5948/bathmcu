package com.example.notishare;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.graphics.drawable.Icon;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.service.notification.StatusBarNotification;
import android.util.Log;

import androidx.core.app.NotificationCompat;

import java.net.MalformedURLException;
import java.net.URL;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;

public class NotificationListenerService extends android.service.notification.NotificationListenerService {
    NotificationManager manager;
    NotificationCompat.Builder builder;
    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        super.onNotificationPosted(sbn);

        Log.d("NotisharTest 1 log", "onNotificationPosted: "+sbn);

        Notification notification = sbn.getNotification();
        Bundle extras = sbn.getNotification().extras;
        String title = extras.getString(Notification.EXTRA_TITLE);
        String text = extras.getString(Notification.EXTRA_TEXT);
        String subText = extras.getString(Notification.EXTRA_SUB_TEXT);
        String bigText = extras.getString(Notification.EXTRA_BIG_TEXT);
        String infoText = extras.getString(Notification.EXTRA_INFO_TEXT);
        String summaryText = extras.getString(Notification.EXTRA_SUMMARY_TEXT);
        Icon smallIcon = notification.getSmallIcon();
        Icon largeIcon = notification.getLargeIcon();





        ApiInterface api = RetrofitClient.getRetrofit().create(ApiInterface.class);
        DTO data = new DTO();
        data.setPackagen(sbn.getPackageName());
        data.setTitle(title);
        data.setText(text);
        data.setBigtext(bigText);
        data.setInfotext(infoText);
        data.setSubtext(subText);
        data.setSt(summaryText);

        Log.d("NotisharTest 1 log", "API BEFORE");
        api.postData(data).enqueue(new Callback<DTO>() {
            @Override
            public void onResponse(Call<DTO> call, Response<DTO> response) {
                if(response.isSuccessful()){
                    Log.d("NotisharTest 1 log", "SUCCES: "+response.body().getResult());
                }
            }

            @Override
            public void onFailure(Call<DTO> call, Throwable t) {
                Log.d("NotisharTest 1 log", "FAILE: "+t);
            }
        });
        //showNoti(); 알림 테스트 실제 배포시 해당 코드 제거 예정
    }
    public void showNoti(){
        Log.d("NotisharTest 1 log", "showNoti: ");
        builder = null;
        manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        //버전 오레오 이상일 경우
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.O){
            manager.createNotificationChannel(
                    new NotificationChannel("channel1", "channel1", NotificationManager.IMPORTANCE_HIGH)
            );

            builder = new NotificationCompat.Builder(this,"channel1")
                    .setPriority(NotificationCompat.PRIORITY_HIGH) // PRIORITY_HIGH로 세팅!!
                    .setDefaults(NotificationCompat.DEFAULT_SOUND | NotificationCompat.DEFAULT_VIBRATE);
            builder.setWhen(11111111);

            //하위 버전일 경우
        }else{
            builder = new NotificationCompat.Builder(this);
        }

        //알림창 제목
        builder.setContentTitle("알림");

        //알림창 메시지
        builder.setContentText("알림 메시지");

        //알림창 아이콘
        builder.setSmallIcon(R.drawable.ic_launcher_background);


        Notification notification = builder.build();

        //알림창 실행
        manager.notify(1,notification);
    }

}
