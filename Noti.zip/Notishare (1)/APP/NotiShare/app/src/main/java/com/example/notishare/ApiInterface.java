package com.example.notishare;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.POST;

public interface ApiInterface {
    @POST("/noti")
    Call<DTO> postData(@Body DTO data);
}
