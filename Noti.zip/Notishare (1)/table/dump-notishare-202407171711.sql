-- MySQL dump 10.13  Distrib 8.0.19, for Win64 (x86_64)
--
-- Host: localhost    Database: notishare
-- ------------------------------------------------------
-- Server version	5.5.5-10.6.18-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tb_notifitation`
--

DROP TABLE IF EXISTS `tb_notifitation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_notifitation` (
  `ID` int(255) NOT NULL AUTO_INCREMENT,
  `PACKAGENAME` longtext DEFAULT NULL,
  `TITLE` longtext DEFAULT NULL,
  `TEXT` longtext DEFAULT NULL,
  `BIGTEXT` longtext DEFAULT NULL,
  `INFOTEXT` longtext DEFAULT NULL,
  `SUBTEXT` longtext DEFAULT NULL,
  `SUMMARYTEXT` longtext DEFAULT NULL,
  `TIME` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_notifitation`
--

LOCK TABLES `tb_notifitation` WRITE;
/*!40000 ALTER TABLE `tb_notifitation` DISABLE KEYS */;
INSERT INTO `tb_notifitation` VALUES (1,'TEST','TEST','TEST','TEST','TEST','TEST','TEST',NULL),(2,'TEST','TEST','TEST','TEST','TEST','TEST','TEST',NULL),(3,'TEST1','TEST1','TEST1','TEST1','TEST1','TEST1','TEST1',NULL),(4,'testPost1','testPost1','testPost1','testPost1','testPost1','testPost1','testPost1',NULL),(5,'testPost1','testPost1','testPost1','testPost1','testPost1','testPost1','testPost1',NULL),(6,'testPost1','testPost1','testPost1','testPost1','testPost1','testPost1','testPost1',NULL),(7,'TEST1','TEST1','TEST1','TEST1','TEST1','TEST1','TEST1','2024-07-17 00:00:00'),(8,'TEST1','TEST1','TEST1','TEST1','TEST1','TEST1','TEST1','2024-07-17 00:00:00'),(9,'TEST1','TEST1','TEST1','TEST1','TEST1','TEST1','TEST1','2024-07-17 11:08:08'),(10,'TEST1','TEST1','TEST1','TEST1','TEST1','TEST1','TEST1','2024-07-17 11:08:10'),(11,'TEST1','TEST1','TEST1','TEST1','TEST1','TEST1','TEST1','2024-07-17 11:08:13'),(12,'testPost1','testPost1','testPost1','testPost1','testPost1','testPost1','testPost1','2024-07-17 11:08:32'),(13,'testPost1','testPost1','testPost1','testPost1','testPost1','testPost1','testPost1','2024-07-17 11:19:55'),(14,'testPost1','testPost1','testPost1','testPost1','testPost1','testPost1','testPost1','2024-07-17 14:57:35'),(15,'com.google.android.apps.messaging','(650) 555-1212','Android is always a sweet treat!\nAndroid is always a sweet treat!Android is always a sweet treat!Android is always a sweet treat!Android is always a sweet treat!Android is always a sweet treat!Android is always a sweet treat!Android is always a sweet treat!Android is always a sweet treat!Android is always a sweet treat!Android is always a sweet treat!Android is always a sweet treat!Android is always a sweet treat!','','','','','2024-07-17 17:04:46'),(16,'com.google.android.apps.messaging','(650) 555-1212','Android is always a sweet treat!\nAndroid is always a sweet treat!Android is always a sweet treat!Android is always a sweet treat!Android is always a sweet treat!Android is always a sweet treat!Android is always a sweet treat!Android is always a sweet treat!Android is always a sweet treat!Android is always a sweet treat!Android is always a sweet treat!Android is always a sweet treat!Android is always a sweet treat!','','','','','2024-07-17 17:04:46'),(17,'com.google.android.apps.messaging','(650) 555-1212','Android is always a sweet treat!\nAndroid is always a sweet treat!Android is always a sweet treat!Android is always a sweet treat!Android is always a sweet treat!Android is always a sweet treat!Android is always a sweet treat!Android is always a sweet treat!Android is always a sweet treat!Android is always a sweet treat!Android is always a sweet treat!Android is always a sweet treat!Android is always a sweet treat!','','','','','2024-07-17 17:08:44'),(18,'com.google.android.apps.messaging','(650) 555-1212','Android is always a sweet treat!\nAndroid is always a sweet treat!Android is always a sweet treat!Android is always a sweet treat!Android is always a sweet treat!Android is always a sweet treat!Android is always a sweet treat!Android is always a sweet treat!Android is always a sweet treat!Android is always a sweet treat!Android is always a sweet treat!Android is always a sweet treat!Android is always a sweet treat!','','','','','2024-07-17 17:08:44');
/*!40000 ALTER TABLE `tb_notifitation` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-07-17 17:11:27
