//모듈 불러오기
const express = require("express"); //EXPRESS (서버 생성)
const db      = require("./database"); //DB 연결
const crypto = require('crypto'); //암호화
require('dotenv').config();// .env 파일에서 환경변수 불러오기

//API 키 가지고 오기
const API_KEY_ORIGIN = process.env.API_KEY;

const API_KEY = crypto.createHash('sha512').update(API_KEY_ORIGIN).digest('base64');

//express 사용
const app = express();

//Express 4.16.0버전 부터 body-parser의 일부 기능이 익스프레스에 내장 body-parser 연결 
app.use(express.json());
app.use(express.urlencoded({ extended: true}));

let lastCount = 0;
//임시 데이터

// "PackageName: $packageName" +
// "Title: $extraTitle\n" +
// "Text: $extraText\n" +
// "BigText: $extraBigText\n" +
// "InfoText: $extraInfoText\n" +
// "SubText: $extraSubText\n" +
// "SummaryText: $extraSummaryText\n"

/**
 * 파라미터 변수 뜻
 * req : request 요청
 * res : response 응답
 */

/**
 * @path {GET} http://localhost:3000/
 * @description 요청 데이터 값이 없고 반환 값이 있는 GET Method
 */

//문자 긁어오기
app.get("/noti/all",(req, res) =>{
    // 해당 데이터 반환
    const key = req.body.APIKEY;
    if(key == API_KEY){
        db.execute(
            "SELECT * FROM TB_NOTIFITATION",
            (error,result)=>{
                if(error){
                    console.log(error);
                    res.json({ result : "false" });
                }else{
                    console.log(result);
                    res.send(result);
                }
            }
        )
        
    }else{
        res.json({ result : "AUTH false" });
    }
  });

//모든데이터 읽기
app.get("/noti",(req, res) =>{
    // 해당 데이터 반환
    const key = req.body.APIKEY;

    if(key == API_KEY){
        db.execute(
            "SELECT COUNT(*) as count  FROM TB_NOTIFITATION",
            (error,result)=>{
                if(error){
                    console.log(error);
                    res.json({ result : "false COUNT" });
                }else{
                    console.log("값 출력");
                    console.log(lastCount);
                    console.log(result[0].count);
                    if(lastCount==result[0].count){
                        res.json({result : "ok",count : lastCount ,new:"NO"});
                        console.log("동일함");
                    }else{
                        console.log("다름");
                        db.execute(
                            "SELECT * FROM TB_NOTIFITATION WHERE ID >?",
                            [lastCount],
                            (error,result)=>{
                                if(error){
                                    console.log(error);
                                    res.json({ result : "false SELECT" });
                                }else{
                                    console.log(result);
                                    res.json({result:"ok",count : result[0].count,new : "YES",data: result});
                                }
                            }
                        )
                        lastCount = result[0].count;
                    }
                }
            }
        )

        
        
    }else{
        res.json({ result : "AUTH false" });
    }
  });

//데이터 갯수 세기
app.get("/noti/count",(req, res) =>{
    // 해당 데이터 반환
    const key = req.body.APIKEY;
    if(key == API_KEY){
        db.execute(
            "SELECT COUNT(*) FROM TB_NOTIFITATION",
            (error,result)=>{
                if(error){
                    console.log(error);
                    res.json({ result : "false" });
                }else{
                    console.log(result);
                    res.send(result);
                }
            }
        )
        
    }else{
        res.json({ result : "AUTH false" });
    }
  });

//특정 데이터 들고오기
app.get("/noti/:id",(req, res) =>{
    // 해당 데이터 반환
    const key = req.body.APIKEY;
    const id = req.params.id;
    if(key == API_KEY){
        db.execute(
            "SELECT * FROM TB_NOTIFITATION WHERE ID = ?",
            [id],
            (error,result)=>{
                if(error){
                    console.log(error);
                    res.json({ result : "false" });
                }else{
                    console.log(result);
                    res.send(result);
                }
            }
        )
        
    }else{
        res.json({ result : "AUTH false" });
    }
  });



//데이터 삽입
app.post("/noti",(req,res)=>{
    // 해당 데이터 반환
    const {
        PACKAGENAME,
        TITLE,
        TEXT,
        BIGTEXT,
        INFOTEXT,
        SUBTEXT,
        SUMMARYTEXT
    }= req.body;

    const key = req.body.APIKEY;

    if(key == API_KEY){
        db.execute(
            "INSERT INTO TB_NOTIFITATION (PACKAGENAME,TITLE,TEXT,BIGTEXT,INFOTEXT,SUBTEXT,SUMMARYTEXT) VALUES(?,?,?,?,?,?,?)",
            [PACKAGENAME, TITLE, TEXT,BIGTEXT,INFOTEXT,SUBTEXT,SUMMARYTEXT]
            ,(error,result)=>{
                if(error){
                    console.log(error);
                    res.json({ result : "false" });
                }else{
                    console.log(result);
                    res.json({ result : "OK" });
                }
            }
        )
    }else{
        console.log("인증실패");
        res.json({ result : "AUTH false" });
    }
});

// http listen port 생성 서버 실행
app.listen(3000, () => console.log("지구본 노티"));


